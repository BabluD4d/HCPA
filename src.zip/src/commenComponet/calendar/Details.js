const Details = (props) => {
  return <div>{props.data}</div>;
};

export default Details;
